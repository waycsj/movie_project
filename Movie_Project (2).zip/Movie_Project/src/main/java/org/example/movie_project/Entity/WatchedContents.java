package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@IdClass(WatchedContentsId.class)
public class WatchedContents {

  @Id
  private int content_id;  // 복합키의 일부

  @Id
  private int user_id;  // 복합키의 일부

  private LocalDate watched_date;

  private int last_watch_point;

  @Column(length = 100)
  private String thumbnail_url;

  // Content와 User 객체를 각각 참조하는 필드
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "content_id", insertable = false, updatable = false)
  private Contents contents;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "user_id", insertable = false, updatable = false)
  private Users users;
}
