package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Collection;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Contents {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int content_id;
  @Column(length = 45)
  private String title;
  @Column(length = 254)
  private String tagline;
  private String overview;
  @Column(precision = 10, scale = 2)
  private String vote_average;
  private int view_count;
  @Column(length = 100)
  private String poster_path;
  @Column(length = 100)
  private String backdrop_path;
  @Column(precision = 10, scale = 2)
  private String popularity;

  private Boolean type;
  private Boolean is_trending;
  private Boolean is_favorite;

  @Column(length = 254)
  private String video_url;


  @OneToMany(mappedBy = "contents")
  private Collection<Genre> genre;
  @OneToMany(mappedBy = "contents", fetch = FetchType.LAZY)
  private List<WatchedContents> watchedContents;


  public Collection<Genre> getGenre() {
    return genre;
  }
  public void setGenre(Collection<Genre> genre) {
    this.genre = genre;
  }

}
