package org.example.movie_project.Entity;

import lombok.*;

import java.io.Serializable;

// Getter, Setter는 생략 (Lombok 사용 시 추가 가능)
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class BookmarkedContentId implements Serializable {

  private int user_id;
  private int content_id;
}
