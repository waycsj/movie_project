package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Users {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int user_id;
  @Column(length = 45)
  private String nickname;
  @Column(length = 254)
  private String password;
  @Column(length = 254)
  private String profile_url;
  @Column(length = 254)
  private String email;

  @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
  private List<WatchedContents> watchedContents;
}
