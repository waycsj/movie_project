package org.example.movie_project.Entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class WatchedContentsId implements Serializable {
  private int content_id;
  private int user_id;
}
