package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Genre {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int genre_id;
  @Column(length = 254)
  private String name;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "contents_id")
  private Contents contents;

  // Genre와의 관계 정의 (One-to-Many) but 단방향 설계로 정함
//  @OneToMany(mappedBy = "content", fetch = FetchType.LAZY)
//  private List<Genre> genres;
}
