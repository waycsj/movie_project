package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;

import java.time.LocalDate;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class LikedContent {
  @EmbeddedId
  private UserContentId userId;//private UserContentId userContentId;

  private LocalDate likedDate;
//  // 복합키에서 userId를 외래키로 사용
//  @ManyToOne
//  @MapsId("userId")
//  @JoinColumn(name = "user_id", referencedColumnName = "userId", nullable = false)
//  private User user;
//  // 복합키에서 contentId를 외래키로 사용
//  @ManyToOne
//  @MapsId("contentId")
//  @JoinColumn(name = "content_id", referencedColumnName = "contentId", nullable = false)
//  private Content content;
}
