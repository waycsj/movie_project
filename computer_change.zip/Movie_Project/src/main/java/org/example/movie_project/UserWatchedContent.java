package org.example.movie_project;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.example.movie_project.Entity.User;
import org.example.movie_project.Entity.WatchedContent;

@Getter
@Setter
@Entity
@Table(name = "user_watched_contents")
public class UserWatchedContent {
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "user_user_id", nullable = false)
  private User userUser;

  @OneToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumns({
      @JoinColumn(name = "watched_contents_content_id", referencedColumnName = "content_id", nullable = false),
      @JoinColumn(name = "watched_contents_user_id", referencedColumnName = "user_id", nullable = false)
  })
  private WatchedContent watchedContent;

}