package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Embeddable
public class WatchedContent {
  @EmbeddedId
  private UserContentId watchedContentId;//원래는 이거였음 private UserContentId watchedContentId;


//  @ManyToOne
//  @MapsId("userId")
//  @JoinColumn(name = "user_id", referencedColumnName = "userId", nullable = false)
//  private User user;
//  // 복합키에서 contentId를 외래키로 사용
//  @ManyToOne
//  @MapsId("contentId")
//  @JoinColumn(name = "content_id", referencedColumnName = "contentId", nullable = false)
//  private Content content;


  private LocalDate watchedDate;
  private int lastWatchPoint;

  @Column(length = 200)
  private String thumbnailUrl;
}
