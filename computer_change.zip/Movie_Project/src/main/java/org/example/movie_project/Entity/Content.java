package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.Collection;
import java.util.List;

@Entity
@Table(name = "contents")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Content {
  @Id
  private int contentId;
  @Column(length = 45)
  private String title;
  @Column(length = 254)
  private String tagline;
  private String overview;
  @Column(precision = 10, scale = 2)
  private String voteAverage;
  private int viewCount;
  @Column(length = 100)
  private String posterPath;
  @Column(length = 100)
  private String backdropPath;
  @Column(precision = 10, scale = 2)
  private String popularity;

  private Boolean type;
  private Boolean isTrending;
  private Boolean isFavorite;

  @Column(length = 254)
  private String videoUrl;

/*
  @OneToMany(mappedBy = "contents")
  private Collection<Genre> genre;
  @OneToMany(mappedBy = "contents", fetch = FetchType.LAZY)
  private List<WatchedContents> watchedContents;


  public Collection<Genre> getGenre() {
    return genre;
  }
  public void setGenre(Collection<Genre> genre) {
    this.genre = genre;
  }
*/
}