
package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class MovieDetails {
  @Id
  @OneToOne(cascade = CascadeType.REMOVE)
  @JoinColumn(name = "content_id")
  private Content content;

  private int runtime;
  private LocalDate releaseDate;
}

