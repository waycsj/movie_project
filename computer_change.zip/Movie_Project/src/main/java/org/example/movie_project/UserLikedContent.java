package org.example.movie_project;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.example.movie_project.Entity.LikedContent;
import org.example.movie_project.Entity.User;

@Getter
@Setter
@Entity
@Table(name = "user_liked_contents")
public class UserLikedContent {
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "user_user_id", nullable = false)
  private User userUser;

  @OneToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumns({
      @JoinColumn(name = "liked_contents_content_id", referencedColumnName = "content_id", nullable = false),
      @JoinColumn(name = "liked_contents_user_id", referencedColumnName = "user_id", nullable = false)
  })
  private LikedContent likedContent;

}