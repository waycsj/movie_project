package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;

// Getter, Setter는 생략 (Lombok 사용 시 추가 가능)
@EqualsAndHashCode
@Embeddable
public class UserContentId implements Serializable {
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "user_id")
  @OnDelete(action = OnDeleteAction.CASCADE)
  private User user;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "content_id")
  @OnDelete(action = OnDeleteAction.CASCADE)
  private Content content;


//  private int userId;
//  private int contentId;
}
