package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;

// Getter, Setter는 생략 (Lombok 사용 시 추가 가능)
@EqualsAndHashCode
@Embeddable
public class UserContentId implements Serializable {
  private int userId;
  private int contentId;


//  @ManyToOne
//  @JoinColumn(name = "user_id")
//  private User user;
//
//
//  @ManyToOne
//  @JoinColumn(name = "content_id")
//  private Content content;



}
