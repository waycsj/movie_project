package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class User {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int userId;
  @Column(length = 45)
  private String nickname;
  @Column(length = 254)
  private String password;
  @Column(length = 254)
  private String profileUrl;
  @Column(length = 254)
  private String email;

  // 관계
  @OneToMany(mappedBy = "user", cascade = CascadeType.REMOVE)
  private List<LikedContent> likedContents;
  @OneToMany(mappedBy = "user", cascade = CascadeType.REMOVE)
  private List<BookmarkedContent> bookmarkedContents;
  @OneToMany(mappedBy = "user", cascade = CascadeType.REMOVE)
  private List<WatchedContent> watchedContents;

}
