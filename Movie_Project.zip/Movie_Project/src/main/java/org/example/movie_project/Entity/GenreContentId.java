package org.example.movie_project.Entity;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;


import java.io.Serializable;


@EqualsAndHashCode
@Embeddable
public class GenreContentId implements Serializable {

  private int genreId;


  @ManyToOne(cascade = CascadeType.REMOVE)
  @JoinColumn(name = "content_id")
  private Content content;
}